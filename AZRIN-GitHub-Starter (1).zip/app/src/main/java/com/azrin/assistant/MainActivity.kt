package com.azrin.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val ComponentActivity.dataStore by preferencesDataStore(name = "azrin_settings")
private val HISTORY_KEY = stringPreferencesKey("chat_history")

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val scope = rememberCoroutineScope()
            val history by dataStore.data.map { prefs -> decodeHistory(prefs[HISTORY_KEY].orEmpty()) }
                .collectAsState(initial = emptyList())
            AzrinScreen(
                messages = history,
                onSend = { text ->
                    val updated = history + ChatMessage(text, true) +
                        ChatMessage("پیامت دریافت شد. اتصال هوش مصنوعی آنلاین در مرحله بعد از طریق سرور امن فعال می‌شود.", false)
                    scope.launch {
                        dataStore.edit { it[HISTORY_KEY] = encodeHistory(updated.takeLast(100)) }
                    }
                },
                onClear = { scope.launch { dataStore.edit { it.remove(HISTORY_KEY) } } }
            )
        }
    }
}

@Composable
private fun AzrinScreen(
    messages: List<ChatMessage>,
    onSend: (String) -> Unit,
    onClear: () -> Unit
) {
    var draft by remember { mutableStateOf("") }
    val bg = Brush.verticalGradient(listOf(Color(0xFF101C35), Color(0xFF172A45), Color(0xFF0D172B)))
    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF8DE4D2), surface = Color(0xFF1B2D49))) {
        Column(Modifier.fillMaxSize().background(bg).statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Box(Modifier.size(54.dp).background(Color(0xFF244B61), CircleShape), contentAlignment = Alignment.Center) {
                    Text("A", color = Color(0xFF9AF1DF), fontSize = 27.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("AZRIN", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("دستیار هوشمند فارسی", color = Color(0xFFB5C8DC), fontSize = 13.sp)
                }
                TextButton(onClick = onClear) { Text("پاک‌کردن", color = Color(0xFFB5C8DC)) }
            }
            Spacer(Modifier.height(18.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0x332F6075)), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("◉", color = Color(0xFF9AF1DF), fontSize = 46.sp)
                    Text("سلام، من ازرین هستم", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text("نسخه پایه در حال توسعه است", color = Color(0xFFB5C8DC), fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), reverseLayout = false, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(messages) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                        Surface(
                            color = if (msg.fromUser) Color(0xFF285B68) else Color(0xFF243650),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.widthIn(max = 300.dp)
                        ) { Text(msg.text, color = Color.White, modifier = Modifier.padding(12.dp), fontSize = 14.sp) }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = draft, onValueChange = { draft = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("پیامت را بنویس…") },
                    shape = RoundedCornerShape(18.dp), singleLine = true
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = { val value = draft.trim(); if (value.isNotEmpty()) { onSend(value); draft = "" } },
                    shape = RoundedCornerShape(16.dp), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp)
                ) { Text("ارسال") }
            }
            Spacer(Modifier.height(5.dp))
            Text("این نسخه هنوز به مدل هوش مصنوعی آنلاین متصل نیست.", color = Color(0xFF9FB2C7), fontSize = 11.sp)
        }
    }
}

private fun encodeHistory(messages: List<ChatMessage>): String {
    val array = JSONArray()
    messages.forEach {
        array.put(JSONObject().put("text", it.text).put("user", it.fromUser))
    }
    return array.toString()
}

private fun decodeHistory(raw: String): List<ChatMessage> = try {
    val array = JSONArray(raw)
    List(array.length()) { i ->
        val item = array.getJSONObject(i)
        ChatMessage(item.optString("text"), item.optBoolean("user"))
    }
} catch (_: Exception) { emptyList() }
